Lines
-----

.. module:: sympy.geometry.line

.. autoclass:: LinearEntity
   :members:

.. autoclass:: Line
   :members:

.. autoclass:: Ray
   :members:

.. autoclass:: Segment
   :members:

.. autoclass:: LinearEntity2D
   :members:

.. autoclass:: Line2D
   :members:

.. autoclass:: Ray2D
   :members:

.. autoclass:: Segment2D
   :members:

.. autoclass:: LinearEntity3D
   :members:

.. autoclass:: Line3D
   :members:

.. autoclass:: Ray3D
   :members:

.. autoclass:: Segment3D
   :members:
