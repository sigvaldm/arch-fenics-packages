Plane
-----

.. automodule:: sympy.geometry.plane
   :members:
