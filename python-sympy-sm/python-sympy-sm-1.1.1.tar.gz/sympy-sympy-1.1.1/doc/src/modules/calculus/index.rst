========
Calculus
========

.. automodule:: sympy.calculus

.. automodule:: sympy.calculus.euler
    :members:

.. automodule:: sympy.calculus.singularities
    :members:

.. automodule :: sympy.calculus.finite_diff
    :members:
