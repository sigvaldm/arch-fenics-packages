=====
Order
=====

.. automodule:: sympy.assumptions.handlers.order
   :members:
