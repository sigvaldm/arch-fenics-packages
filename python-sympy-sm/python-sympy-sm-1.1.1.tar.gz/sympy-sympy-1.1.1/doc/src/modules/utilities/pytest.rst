======
pytest
======

.. automodule:: sympy.utilities.pytest
   :members:
