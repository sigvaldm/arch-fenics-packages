======
Medium
======

.. automodule:: sympy.physics.optics.medium
   :members:
