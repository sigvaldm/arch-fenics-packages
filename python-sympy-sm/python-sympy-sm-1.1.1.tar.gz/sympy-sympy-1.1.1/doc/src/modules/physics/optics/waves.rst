======
Waves
======

.. automodule:: sympy.physics.optics.waves
   :members:
