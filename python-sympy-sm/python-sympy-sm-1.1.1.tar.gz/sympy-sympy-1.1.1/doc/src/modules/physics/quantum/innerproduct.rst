=============
Inner Product
=============

.. automodule:: sympy.physics.quantum.innerproduct
   :members:
