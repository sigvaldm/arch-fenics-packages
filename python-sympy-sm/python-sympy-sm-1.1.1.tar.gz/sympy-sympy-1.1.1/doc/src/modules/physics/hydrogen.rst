======================
Hydrogen Wavefunctions
======================

.. automodule:: sympy.physics.hydrogen
   :members:
