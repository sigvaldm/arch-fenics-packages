.. _tensor_module:

=============
Tensor Module
=============

.. automodule:: sympy.tensor

Contents
========

.. toctree::
    :maxdepth: 3

    array.rst
    indexed.rst
    index_methods.rst
    tensor.rst
